from pathlib import Path
import json,torch
from compatible import *
from curriculum_gate import forward_gate,next_stage
torch.manual_seed(123)
cmd=torch.tensor([[.25,0,0],[.25,0,0],[.25,0,0],[.25,0,0]])
vel=torch.tensor([[.25,0,0],[0.,0,0],[.25,.4,0],[10.,0,0]])
ang=torch.tensor([[0.,0,0],[0.,0,0],[0.,0,1.],[0.,0,10.]])
height=torch.tensor([.78,.78,.5,.1])
xy,yaw,support=stability_cost_values(cmd,vel,ang,height)
assert xy[0]==0 and 0<xy[1]<xy[2]<=xy[3]==4
assert yaw[0]==0 and yaw[2]>0 and yaw[3]==4
assert support[0]==1 and support[2]<.001
for stage in (0,1,2):
 x=sample_curriculum_targets(10000,stage,"cpu")
 assert torch.isfinite(x).all() and x[:,0].min()>=-.5 and x[:,0].max()<=1
 assert x[:,1:].abs().max()<=1
 if stage==0: assert (x[:,1:]==0).all() and (x[:,0]>=0).all()
 if stage==1: assert (x[:,0]>=0).all() and x[:,1].abs().max()<=.15
 if stage==2: assert (x[:,0]<0).any()
assert next_stage(0,False,True)==0
assert next_stage(0,True,False)==1
assert next_stage(1,True,False)==1
assert next_stage(1,True,True)==2
assert next_stage(2,False,False)==1
old=Path("/home/aril/rai-training/ys-walk-movement-pilot-20261127/iteration_1000/rollout_result.json")
trials=json.loads(old.read_text())
bad,_=forward_gate(trials)
assert not bad
control=[{**x,"policy":"candidate"} for x in trials if x["policy"]=="supplied"]
good,detail=forward_gate(control)
assert good,detail
cfg=make_cfg(2)
assert cfg.rewards["unwanted_yaw"].weight<0 and cfg.rewards["action_magnitude"].weight<0
assert cfg.rewards["track_angular_velocity"].weight==4
result={"reward_costs_pass":True,"command_sampling_pass":True,"stage_gates_pass":True,
    "previous_failed_candidate_rejected":not bad,"supplied_control_accepted":good}
Path("stability_test_result.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result))
