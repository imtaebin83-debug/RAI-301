import math
def forward_gate(trials):
    candidates=[x for x in trials if x["policy"]=="candidate"]
    passed=bool(candidates)
    details=[]
    for row in candidates:
        group=[]
        for sample in row["samples"]:
            if sample["command"]==[.25,0,0]: group.append(sample)
            elif group: break
        forward=side=0.
        if len(group)>1:
            dx=group[-1]["position"][0]-group[0]["position"][0]
            dy=group[-1]["position"][1]-group[0]["position"][1]
            yaw=row["start_yaw"]
            forward=dx*math.cos(yaw)+dy*math.sin(yaw)
            side=-dx*math.sin(yaw)+dy*math.cos(yaw)
        ok=(row["failure"] is None and forward>=.6 and abs(side)<=.25
            and row["linear_velocity_rmse"] is not None and row["linear_velocity_rmse"]<=.15
            and row["yaw_velocity_rmse"] is not None and row["yaw_velocity_rmse"]<=.25
            and row["max_tilt_degrees"]<20)
        details.append({"forward_m":forward,"lateral_drift_m":side,"pass":ok})
        passed=passed and ok
    return passed,details

def next_stage(current,forward_ok,broad_ok):
    # Regress one level on demonstrated forward instability; retain rehearsal.
    if not forward_ok:return max(0,current-1)
    if current==0:return 1
    if current==1 and broad_ok:return 2
    return current
