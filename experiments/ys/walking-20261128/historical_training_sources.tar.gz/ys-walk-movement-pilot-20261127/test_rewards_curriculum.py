import json
from pathlib import Path
import torch
from compatible import *
torch.manual_seed(42)
cmd=torch.tensor([[.25,0,0]]).repeat(7,1)
vel=torch.tensor([[.25,0,0],[0,0,0],[-.25,0,0],[2.,0,0],[.25,0,0],[.25,0,0],[.25,0,0]])
gravity=torch.tensor([[0.,0.,-1.]]).repeat(7,1)
gravity[4,2]=0
height=torch.ones(7)*.79;height[5]=.4;cmd[6]=0
score=directional_progress_score(cmd,vel,gravity,height)
torch.testing.assert_close(score,torch.tensor([1.,0.,-1.,1.,0.,0.,0.]))
# The combined linear objective must prefer matching over idle, wrong-direction,
# lateral drift and large overspeed; all other rewards held equal.
tracking=5*torch.exp(-((cmd[:,:2]-vel[:,:2])**2).sum(1)/.18**2)
total=tracking+2*score
assert total[0]>total[1]>total[2]
assert total[0]>total[3]
assert command_stage(300*24-1)==0 and command_stage(300*24)==1
assert command_stage(650*24-1)==1 and command_stage(650*24)==2
stats={}
for stage,step in [(0,0),(1,300*24),(2,650*24)]:
    x=sample_curriculum_targets(20000,step,"cpu")
    assert torch.isfinite(x).all()
    assert torch.all(x[:,0]>=-.5) and torch.all(x[:,0]<=1)
    assert torch.all(torch.abs(x[:,1])<=.5) and torch.all(torch.abs(x[:,2])<=1)
    active=torch.linalg.vector_norm(x,dim=1)>.001
    assert torch.linalg.vector_norm(x[active],dim=1).min()>=.14999
    fraction=float((~active).float().mean())
    assert .035<fraction<.065
    if stage==0: assert (x[:,1:]==0).all() and (x[:,0]>=0).all()
    if stage==1: assert (x[:,1]==0).all() and (x[:,0]>=0).all() and (x[:,2]!=0).any()
    if stage==2: assert (x[:,0]<0).any() and (x[:,1]<0).any() and (x[:,1]>0).any()
    stats[stage]={"idle_fraction":fraction,"forward_fraction":float((x[:,0]>0).float().mean()),
        "backward_fraction":float((x[:,0]<0).float().mean()),
        "lateral_fraction":float((x[:,1]!=0).float().mean()),
        "turn_fraction":float((x[:,2]!=0).float().mean())}
cfg=make_cfg(2)
assert cfg.rewards["track_linear_velocity"].params["std"]==.18
assert cfg.rewards["directional_progress"].weight==2
result={"reward_ordering_passed":True,"overspeed_bounded":True,"fall_and_idle_gates_passed":True,
    "stages":stats}
Path("reward_curriculum_result.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
