"""Use the official MuJoCo environment and unmodified loader, no policy replacement."""
import sys,json,time,hashlib
from pathlib import Path
import numpy as np
import onnxruntime as ort
import mujoco
BASE=Path("/home/aril/rai-worktrees/ys-all-v2-20261127")
sys.path.insert(0,str(BASE/"src"))
from ros2_bridge.tools.interactive_sim import InteractiveSim
from ros2_bridge.tools.g1_walk_policy_29dof import G1WalkPolicy29DoF
root=Path.cwd()
data=np.load(root/"export_parity.npz")
session=ort.InferenceSession(str(root/"small_policy.onnx"),providers=["CPUExecutionProvider"])
assert session.get_inputs()[0].shape==[1,98]
assert session.get_outputs()[0].shape==[1,29]
actual=np.concatenate([session.run(None,{session.get_inputs()[0].name:row[None]})[0] for row in data["inputs"]])
np.testing.assert_allclose(actual,data["expected"],atol=2e-5,rtol=2e-5)
parity={"samples":len(actual),"max_abs_error":float(np.max(np.abs(actual-data["expected"]))),
        "input":[1,98],"output":[1,29],"provider":session.get_providers()}
(root/"export_result.json").write_text(json.dumps(parity,indent=2))
print("EXPORT",parity,flush=True)
sim=InteractiveSim(BASE/"src/environment/test_zone/world/layout.json",static_scene=True)
spawn=sim.spawn_robot("g1_sensors",pos=(16,11),yaw=0,keyframe=None,hold_keyframe=False,prefix="ys_training_test")
model=sim.model
initial_qpos=sim.data.qpos.copy()
physics={key:getattr(model.opt,key).tolist() if isinstance(getattr(model.opt,key),np.ndarray) else int(getattr(model.opt,key)) if key in ("iterations","ls_iterations","noslip_iterations","integrator","cone","jacobian","enableflags") else float(getattr(model.opt,key)) for key in ("timestep","gravity","impratio","iterations","ls_iterations","noslip_iterations","integrator","cone","jacobian","enableflags")}
(root/"competition_physics.json").write_text(json.dumps(physics,indent=2))
supplied=BASE/"src/environment/robots/control/g1/walking/g1_29dof_velocity.onnx"
cases=[("supplied",supplied,4),("candidate",root/"small_policy.onnx",4),
       ("supplied_no_slip_off",supplied,0),("candidate_no_slip_off",root/"small_policy.onnx",0)]
results=[]
for label,path,noslip in cases:
    model.opt.noslip_iterations=noslip
    d=mujoco.MjData(model)
    d.qpos[:]=initial_qpos
    p=G1WalkPolicy29DoF(model,d,path,prefix=spawn.prefix)
    p.reset(pos=spawn.pos,yaw=0)
    mujoco.mj_forward(model,d)
    trace=[((0,0,0),1),((.25,0,0),5),((0,0,0),1),
           ((0,.15,0),3),((0,0,.3),3),((0,0,0),1),((.2,0,0),3)]
    minimum=float(d.qpos[p.root_qadr+2]); completed=[];finite=True;failed=None
    start=time.monotonic()
    samples=[]
    for command,duration in trace:
        p.set_command(*command)
        begin=d.time
        for step in range(round(duration/model.opt.timestep)):
            p.control(model,d);mujoco.mj_step(model,d)
            height=float(d.qpos[p.root_qadr+2]);minimum=min(minimum,height)
            finite=bool(np.isfinite(d.qpos).all() and np.isfinite(d.qvel).all() and np.isfinite(p.action).all())
            if step%50==0:
                samples.append({"t":float(d.time),"position":d.qpos[p.root_qadr:p.root_qadr+3].tolist(),
                     "command":list(command),"action_norm":float(np.linalg.norm(p.action))})
            if not finite or height<.45:
                failed={"reason":"nonfinite" if not finite else "fell_below_0.45m","time":float(d.time),"command":command}
                break
        completed.append({"command":command,"requested_seconds":duration,"actual_seconds":float(d.time-begin)})
        if failed: break
    result={"policy":label,"noslip_iterations":noslip,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "loader_accepted":True,"finite":finite,"minimum_root_height":minimum,
        "simulated_seconds":float(d.time),"wall_seconds":time.monotonic()-start,
        "failure":failed,"segments":completed,"samples":samples}
    results.append(result)
    (root/"rollout_result.json").write_text(json.dumps(results,indent=2))
    print("ROLLOUT",{k:v for k,v in result.items() if k not in ("samples","segments")},flush=True)
print("DONE",flush=True)
