"""Isolated HAIC-v2 active-walking training configuration; never edits deployment."""
from pathlib import Path
from dataclasses import dataclass
import numpy as np
import mujoco
import torch
from contract import *
from mjlab.entity import EntityCfg, EntityArticulationInfoCfg
from mjlab.actuator.xml_actuator import XmlPositionActuatorCfg
from mjlab.tasks.velocity.config.g1.env_cfgs import unitree_g1_flat_env_cfg
from mjlab.tasks.velocity.mdp.velocity_command import UniformVelocityCommand, UniformVelocityCommandCfg
from mjlab.managers.observation_manager import ObservationGroupCfg, ObservationTermCfg
from mjlab.envs import mdp
from mjlab.envs.mdp.actions.actions import JointPositionAction, JointPositionActionCfg

BASE=Path("/home/aril/rai-worktrees/ys-all-v2-20261127")
ASSET=BASE/"src/environment/robots/mujoco/g1/models/g1_dex_sensors_missions.xml"

def robot_spec():
    spec=mujoco.MjSpec.from_file(str(ASSET))
    # Absolute resources survive attaching the source robot to MJLab's world.
    for mesh in spec.meshes:
        if mesh.file:
            mesh.file=str(ASSET.parent/"assets"/Path(mesh.file).name)
    for texture in spec.textures:
        if texture.file:
            texture.file=str(ASSET.parent/texture.file)
    spec.meshdir=""
    for key in list(spec.keys):
        spec.delete(key)
    for name,kp,kd in zip(JOINTS,KP,KD):
        actuator=next(a for a in spec.actuators if a.target==name)
        actuator.gainprm[0]=kp
        actuator.biasprm[1]=-kp
        actuator.biasprm[2]=-kd
    return spec

class CompetitionCommand(UniformVelocityCommand):
    """Slew, phase and restart memory match active calls of the official loader."""
    def __init__(self,cfg,env):
        super().__init__(cfg,env)
        self.target=torch.zeros_like(self.vel_command_b)
        self.phase=torch.zeros(self.num_envs,device=self.device,dtype=torch.float64)
        self.idle=torch.ones(self.num_envs,device=self.device,dtype=torch.bool)
        self.woke=torch.zeros_like(self.idle)
        self.tick=torch.full((self.num_envs,),-1,device=self.device,dtype=torch.long)

    def _resample_command(self,ids):
        old=self.vel_command_b[ids].clone()
        super()._resample_command(ids)
        self.target[ids]=self.vel_command_b[ids]
        self.target[ids[self.is_standing_env[ids]]]=0
        self.vel_command_b[ids]=old

    def reset(self,env_ids=None):
        ids=slice(None) if env_ids is None else env_ids
        self.vel_command_b[ids]=0
        self.phase[ids]=0
        self.idle[ids]=True
        self.tick[ids]=-1
        return super().reset(env_ids)

    def _update_command(self):
        self.advance()

    def advance(self):
        fresh=self.tick!=self._env.common_step_counter
        if not fresh.any(): return
        active=torch.linalg.vector_norm(self.target,dim=1)>1e-3
        self.woke=fresh & self.idle & active
        self.phase[self.woke]=0
        self.idle[self.woke]=False
        limit=torch.tensor((1.2,1.2,2.4),device=self.device)*POLICY_DT
        delta=torch.clamp(self.target-self.vel_command_b,-limit,limit)
        self.vel_command_b[fresh]+=delta[fresh]
        stopped=(~active)&(torch.linalg.vector_norm(self.vel_command_b,dim=1)<=1e-3)
        self.idle[fresh & stopped]=True
        self.vel_command_b[fresh & stopped]=0
        running=fresh & ~self.idle
        self.phase[running]=(self.phase[running]+POLICY_DT/GAIT_PERIOD)%1
        self.tick[fresh]=self._env.common_step_counter

@dataclass(kw_only=True)
class CompetitionCommandCfg(UniformVelocityCommandCfg):
    def build(self,env): return CompetitionCommand(self,env)

def pack_observation(ang,gravity,cmd,phase,q,dq,previous):
    moving=torch.linalg.vector_norm(cmd,dim=1)>=0.1
    phase_obs=torch.stack((torch.sin(2*torch.pi*phase),torch.cos(2*torch.pi*phase)),dim=1).to(q.dtype)
    phase_obs[~moving]=0
    default=torch.as_tensor(DEFAULT_POS,device=q.device,dtype=q.dtype)
    return torch.cat((ang,gravity,cmd,phase_obs,q-default,dq,previous),dim=1)

def actor_obs(env):
    command=env.command_manager.get_term("twist")
    command.advance()
    data=env.scene["robot"].data
    previous=env.action_manager.action.clone()
    previous[command.woke | command.idle]=0
    return pack_observation(data.root_link_ang_vel_b,data.projected_gravity_b,
        command.command,command.phase,data.joint_pos,data.joint_vel,previous)

class CompetitionAction(JointPositionAction):
    def apply_actions(self):
        command=self._env.command_manager.get_term("twist")
        target=self._processed_actions.clone()
        target[command.idle]=self._offset[command.idle]
        self._entity.set_joint_position_target(target,joint_ids=self._target_ids)

@dataclass(kw_only=True)
class CompetitionActionCfg(JointPositionActionCfg):
    def build(self,env): return CompetitionAction(self,env)

def make_cfg(num_envs=512):
    cfg=unitree_g1_flat_env_cfg()
    cfg.scene.num_envs=num_envs
    cfg.scene.entities={"robot":EntityCfg(
        spec_fn=robot_spec,
        init_state=EntityCfg.InitialStateCfg(pos=(0,0,0.79),
            joint_pos=dict(zip(JOINTS,map(float,DEFAULT_POS))),joint_vel={".*":0.0}),
        articulation=EntityArticulationInfoCfg(
            actuators=(XmlPositionActuatorCfg(target_names_expr=(".*",)),)),
    )}
    cfg.actions["joint_pos"]=CompetitionActionCfg(entity_name="robot",
        actuator_names=(".*",),scale=dict(zip(JOINTS,map(float,ACTION_SCALE))))
    cfg.commands["twist"]=CompetitionCommandCfg(entity_name="robot",
        resampling_time_range=(3.0,8.0),rel_standing_envs=0.1,
        heading_command=False,rel_heading_envs=0.0,init_velocity_prob=0.0,debug_vis=False,
        ranges=UniformVelocityCommandCfg.Ranges(
            lin_vel_x=(-0.5,1.0),lin_vel_y=(-0.5,0.5),ang_vel_z=(-1.0,1.0)))
    cfg.observations["actor"]=ObservationGroupCfg(
        terms={"competition":ObservationTermCfg(func=actor_obs)},
        concatenate_terms=True,enable_corruption=False)
    # Privileged critic is training-only. No linear velocity/contact/height enters actor.
    cfg.observations["critic"].terms["competition"]=ObservationTermCfg(func=actor_obs)
    cfg.decimation=CONTROL_DECIMATION
    cfg.sim.mujoco.timestep=NOMINAL_DT
    cfg.sim.mujoco.gravity=(0,0,-9.8)
    cfg.sim.mujoco.iterations=100
    cfg.sim.mujoco.ls_iterations=50
    cfg.sim.mujoco.jacobian="sparse"
    cfg.sim.mujoco.multiccd=True
    cfg.sim.mujoco.cone="elliptic"
    cfg.sim.mujoco.impratio=10
    cfg.sim.nconmax=128
    cfg.sim.njmax=512
    # Stage 1 checks exact nominal mechanics before robustness randomization.
    cfg.events={k:v for k,v in cfg.events.items() if k in ("reset_base","reset_robot_joints")}
    cfg.events["reset_base"].params["pose_range"]={"yaw":(-3.14,3.14)}
    cfg.curriculum={}
    return cfg
