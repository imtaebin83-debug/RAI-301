import argparse,json,time
from pathlib import Path
from dataclasses import asdict
import mujoco
import numpy as np
import torch
from compatible import make_cfg,JOINTS,DEFAULT_POS,ACTION_SCALE
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import RslRlVecEnvWrapper
from mjlab.rl.runner import MjlabOnPolicyRunner
from mjlab.tasks.velocity.config.g1.rl_cfg import unitree_g1_ppo_runner_cfg
parser=argparse.ArgumentParser()
parser.add_argument("--iterations",type=int,default=200)
parser.add_argument("--envs",type=int,default=512)
parser.add_argument("--full-training",action="store_true",help="Explicitly allow more than 500 iterations after reviewing preflight evidence")
args=parser.parse_args()
if args.iterations>500 and not args.full_training:
    parser.error("Runs above 500 iterations require --full-training after reviewing preflight evidence.")
if args.iterations<1 or args.envs<1:
    parser.error("iterations and envs must be positive")
from preflight import verify_sources
verify_sources()
out=Path.cwd()
if (out/"small_checkpoint.pt").exists() or (out/"small_policy.onnx").exists():
    parser.error("Use a fresh output directory to preserve existing checkpoints.")
torch.manual_seed(42)
start=time.monotonic()
env=ManagerBasedRlEnv(make_cfg(args.envs),device="cuda:0")
assert tuple(env.scene["robot"].joint_names)==tuple(JOINTS)
wrapped=RslRlVecEnvWrapper(env,clip_actions=None)
obs=wrapped.get_observations()
assert obs["actor"].shape==(args.envs,98) and torch.isfinite(obs["actor"]).all()
# Independently compare the attached training robot with the original robot.
from compatible import robot_spec
reference=robot_spec().compile()
model=env.sim.mj_model
checks={}
for kind,fields in [(mujoco.mjtObj.mjOBJ_BODY,("body_mass","body_inertia","body_ipos","body_iquat")),
                    (mujoco.mjtObj.mjOBJ_JOINT,("jnt_range","jnt_axis","jnt_pos")),
                    (mujoco.mjtObj.mjOBJ_ACTUATOR,("actuator_gainprm","actuator_biasprm","actuator_forcerange"))]:
    for i in range({mujoco.mjtObj.mjOBJ_BODY:reference.nbody,mujoco.mjtObj.mjOBJ_JOINT:reference.njnt,mujoco.mjtObj.mjOBJ_ACTUATOR:reference.nu}[kind]):
        name=mujoco.mj_id2name(reference,kind,i)
        if not name or name=="world": continue
        j=mujoco.mj_name2id(model,kind,"robot/"+name)
        assert j>=0,(name,"missing in training")
        for field in fields:
            np.testing.assert_allclose(getattr(model,field)[j],getattr(reference,field)[i],atol=1e-9)
            checks[field]=checks.get(field,0)+1
# Test frame conversion against raw free-joint angular velocity at randomized yaw.
robot=env.scene["robot"]
angular_ids=robot.indexing.free_joint_v_adr[3:6]
env.sim.data.qvel[:,angular_ids]=torch.tensor((0.2,-0.3,0.4),device=env.device)
env.sim.forward()
raw=env.sim.data.qvel[:,angular_ids]
np.testing.assert_allclose(robot.data.root_link_ang_vel_b.cpu(),raw.cpu(),atol=1e-6)
wrapped.reset()
(out/"physical_parity.json").write_text(json.dumps(checks,indent=2))
(out/"source_config.py.txt").write_text(Path(__file__).with_name("compatible.py").read_text())
physics={key:getattr(model.opt,key).tolist() if isinstance(getattr(model.opt,key),np.ndarray) else float(getattr(model.opt,key)) for key in ("timestep","gravity","impratio","iterations","ls_iterations","noslip_iterations","integrator","cone","jacobian")}
(out/"training_physics.json").write_text(json.dumps(physics,indent=2))
action=env.action_manager.get_term("joint_pos")
np.testing.assert_allclose(action.offset[0].cpu(),DEFAULT_POS,atol=1e-7)
np.testing.assert_allclose(action.scale[0].cpu(),ACTION_SCALE,atol=1e-7)
agent=unitree_g1_ppo_runner_cfg()
agent.max_iterations=args.iterations
agent.save_interval=args.iterations
agent.logger="tensorboard"
agent.upload_model=False
(out/"agent.json").write_text(json.dumps(asdict(agent),indent=2))
runner=MjlabOnPolicyRunner(wrapped,asdict(agent),log_dir=str(out/"logs"),device="cuda:0")
initial={k:v.detach().cpu().clone() for k,v in runner.alg.get_policy().state_dict().items()}
train_start=time.monotonic()
runner.learn(num_learning_iterations=args.iterations,init_at_random_ep_len=False)
elapsed=time.monotonic()-train_start
runner.save(str(out/"small_checkpoint.pt"))
policy=runner.alg.get_policy()
assert all(torch.isfinite(v).all() for v in policy.state_dict().values())
changed=sum(not torch.equal(initial[k],v.detach().cpu()) for k,v in policy.state_dict().items())
assert changed>0
runner.export_policy_to_onnx(str(out),"small_policy.onnx")
module=policy.as_onnx(verbose=False).cpu().eval()
dummy=module.get_dummy_inputs()
sample=dummy[0] if isinstance(dummy,tuple) else dummy
print("EXPORT_SHAPE",sample.shape,flush=True)
generator=torch.Generator().manual_seed(123)
x=torch.randn((100,98),generator=generator)*0.25
x[:,5]=-1
with torch.no_grad():
    expected=torch.cat([module(row[None]) for row in x]).numpy()
np.savez(out/"export_parity.npz",inputs=x.numpy(),expected=expected)
result={"iterations":args.iterations,"num_envs":args.envs,"actor_shape":list(obs["actor"].shape),
    "changed_tensors":changed,"train_seconds":elapsed,"total_seconds":time.monotonic()-start,
    "seconds_per_iteration_including_startup":elapsed/args.iterations,
    "projection_30000_hours":elapsed/args.iterations*30000/3600}
(out/"training_result.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
env.close()
