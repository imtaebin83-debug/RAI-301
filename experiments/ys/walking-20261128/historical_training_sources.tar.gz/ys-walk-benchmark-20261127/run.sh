#!/bin/bash
cd /home/aril/rai-training/ys-walk-benchmark-20261127
export CUDA_VISIBLE_DEVICES=0 MUJOCO_GL=egl PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 WANDB_MODE=disabled
nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu,temperature.gpu,power.draw --format=csv -l 5 > gpu.csv &
monitor=$!
trap 'kill "$monitor" 2>/dev/null || true' EXIT
date -Iseconds > started.txt
timeout --signal=TERM --kill-after=20s 1200 /home/aril/miniforge3/envs/unitree_mjlab_omen5060/bin/python -u -m mjlab.scripts.train Mjlab-Velocity-Flat-Unitree-G1 --env.scene.num-envs 256 --agent.max-iterations 100 --agent.save-interval 100 --agent.logger tensorboard --agent.experiment-name ys_walk_benchmark --agent.run-name env256
rc=$?
date -Iseconds > ended.txt
printf '%s\n' "$rc" > exit.txt
exit "$rc"
